﻿using System;
using System.Collections.Generic;

namespace Proyecto_Financiero
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombre, DPI, direccion, telefono, TipoCuenta, NumCuenta = "";
            double saldoInicial = 2500.00;

            Console.WriteLine("Ingrese su Nombre Completo:");
            nombre = Console.ReadLine();

            Console.WriteLine("Ingresar su DPI de máximo 5 caracteres:");
            DPI = Console.ReadLine();

            while (DPI.Length > 5)
            {
                Console.WriteLine("El número de caracteres es mayor a 5. Ingrese su DPI de máximo 5 caracteres:");
                DPI = Console.ReadLine();
            }

            Console.WriteLine("Ingrese su dirección:");
            direccion = Console.ReadLine();

            Console.WriteLine("Ingrese su número de telefono:");
            telefono = Console.ReadLine();
            
            Console.WriteLine("Ingrese su tipo de cuenta:");
            Console.WriteLine("AHORRO QUETZALES /  QUETZALES MONETARIA / DOLARES AHORRO / DOLARES MONETARIA");
            TipoCuenta = Console.ReadLine();

            Console.WriteLine("Ingrese su Número de cuenta:");
            NumCuenta = Console.ReadLine();

            Console.WriteLine("Datos de la cuenta ingresados correctamente. Presione cualquier tecla para continuar...");
            Console.ReadKey();

            CuentaBancaria cuenta = new CuentaBancaria(saldoInicial);

            menu(ref cuenta, nombre, DPI, direccion, telefono, TipoCuenta, NumCuenta);

            Console.WriteLine("Gracias por utilizar nuestro sistema. Presione cualquier tecla para salir...");
            Console.ReadKey();
        }

        static void menu(ref CuentaBancaria cuenta, string nombre, string DPI, string direccion, string telefono, string TipoCuenta, string NumCuenta)
        {
            char opcion;

            do
            {
                Console.Clear();
                MostrarMenu();

                opcion = Console.ReadKey().KeyChar;

                switch (opcion)
                {
                    case '1':
                        cuenta.VerInformacion(nombre, DPI, direccion, telefono, TipoCuenta, NumCuenta);
                        break;
                    case '2':
                        cuenta.ComprarProductoFinanciero();
                        break;
                    case '3':
                        cuenta.VenderProductoFinanciero();
                        break;
                    case '4':
                        cuenta.AbonarACuenta();
                        break;
                    case '5':
                        cuenta.SimularPasoDelTiempo();
                        break;
                    case '6':
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\nOpción inválida. Por favor, seleccione una opción válida.");
                        break;
                }

                Console.WriteLine("\nPresione cualquier tecla para continuar...");
                Console.ReadKey();

            } while (opcion != '6');
        }

        static void MostrarMenu()
        {
            Console.WriteLine("\nMenu de opciones:");
            Console.WriteLine("1. Ver información de la cuenta");
            Console.WriteLine("2. Comprar producto financiero");
            Console.WriteLine("3. Vender producto financiero");
            Console.WriteLine("4. Abonar a cuenta");
            Console.WriteLine("5. Simular paso del tiempo");
            Console.WriteLine("6. Salir");
            Console.Write("Seleccione una opción: ");
        }
    }

    class CuentaBancaria
    {
        private double saldo;
        private List<string> operaciones;

        public CuentaBancaria(double saldoInicial)
        {
            saldo = saldoInicial;
            operaciones = new List<string>();
        }

        public void VerInformacion(string nombre, string DPI, string direccion, string telefono, string TipoCuenta, string NumCuenta)
        {
            Console.WriteLine("Nombre: " + nombre);
            Console.WriteLine("DPI: " + DPI);
            Console.WriteLine("Dirección: " + direccion);
            Console.WriteLine("Teléfono: " + telefono);
            Console.WriteLine("Tipo de Cuenta: " + TipoCuenta);
            Console.WriteLine("Número de Cuenta: " + NumCuenta);
            Console.WriteLine("Saldo actual: Q " + saldo);
            Console.WriteLine("Operaciones realizadas:");
            foreach (string operacion in operaciones)
            {
                Console.WriteLine(operacion);
            }
        }

        public void ComprarProductoFinanciero()
        {
            double descuento = saldo * 0.10;
            saldo -= descuento;
            operaciones.Add($"Compra de producto financiero: -{descuento}. Saldo restante: {saldo}");
            Console.WriteLine($"Se realizó la compra. Nuevo saldo: Q {saldo}");
        }

        public void VenderProductoFinanciero()
        {
            if (saldo > 500)
            {
                double ganancia = saldo * 0.11;
                saldo += ganancia;
                operaciones.Add($"Venta de producto financiero: +{ganancia}. Saldo restante: {saldo}");
                Console.WriteLine($"Se realizó la venta. Nuevo saldo: Q {saldo}");
            }
            else
            {
                Console.WriteLine("No es posible realizar la transacción debido al saldo actual.");
                Console.WriteLine("Porcentaje de la ganancia: 11%");
            }
        }

        public void AbonarACuenta()
        {
            if (operaciones.Count < 2)
            {
                saldo *= 2;
                operaciones.Add($"Abono a cuenta: {saldo}. Saldo restante: {saldo}");
                Console.WriteLine($"Se realizó el abono. Nuevo saldo: Q {saldo}");
            }
            else
            {
                Console.WriteLine("No es posible realizar más abonos este mes.");
            }
        }

        public void SimularPasoDelTiempo()
        {
            Console.WriteLine("Seleccione el periodo de capitalización:");
            Console.WriteLine("1. Una vez al mes");
            Console.WriteLine("2. Dos veces al mes");

            int opcion = int.Parse(Console.ReadLine());

            double tasaDeInteres = 0.02; // 2%
            double interes;

            if (opcion == 1)
            {
                interes = saldo * tasaDeInteres;
                saldo += interes;
                Console.WriteLine($"Saldo después de una capitalización mensual: Q {saldo}");
            }
            else if (opcion == 2)
            {
                interes = saldo * tasaDeInteres * 2;
                saldo += interes;
                Console.WriteLine($"Saldo después de dos capitalizaciones mensuales: Q {saldo}");
            }
            else
            {
                Console.WriteLine("Opción inválida. Seleccione una opción válida.");
            }
        }
    }
}