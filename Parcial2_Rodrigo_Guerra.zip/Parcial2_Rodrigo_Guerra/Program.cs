﻿using System.ComponentModel.Design;
using System.Reflection.Metadata;
using System.Security.Cryptography.X509Certificates;

namespace Parcial2
{

    class program
    {
        
        private static int i;

        public static void main(string[] args)
        {
            string[] nombres = new string[10];
            int[] notas = new int[10];

            for (int i = 0; i < nombres.Length; i++)

            Console.WriteLine("Ingrese su nombre completo");
            nombres[i] = Console.ReadLine();
            {
                Console.WriteLine("Ingrese la nota del alumno. Nota: Esta debe de ser entre (0-100)");
                string input = Console.ReadLine();
                if (int.Parse(Console.ReadLine();
                {
                    if (notas[0] >= 0 && notas[10] <= 10)
                    {
                        notas[0] = notas[10];
                        notas = true
                    }
                    else
                    {
                        Console.WriteLine("Nota invalida, vuelva a ingresar su nota");
                    }
                }
            }
            static void Menu()
            {
                Console.WriteLine("\n Menu:");
                Console.WriteLine("1) Mostrar nombre y nota de alumnos que aprobaron el curso");
                Console.WriteLine("2) Mostrar nombre y nota de alumnos que No aprobaron el curso.");
                Console.WriteLine("3) Mostrar el promedio de notas del grupo.");
                Console.WriteLine("4) Salir del programa");
                Console.WriteLine("Seleccione una opcion");
                Console.ReadLine();
                {
                    switch (opcion)
                    {
                        case 1:
                            Console.WriteLine("Alumnos que aprobaron el curso");
                            for (int i = 0;i < nombres.Length;i++)
                            {
                              if (notas[0] >= 65)
                            }
                            Console.WriteLine($")
                         

                            break;
                    }
                       case 2:
                            Console.WriteLine()


                                break;
                       

                       case 3: 
                        Console.WriteLine()


                            break;

                    case 4:
                        Console.WriteLine("saliendo del programa");
                        
                    }



